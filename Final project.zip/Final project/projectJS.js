function meal() {
    // Getting the input elements by their IDs
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let goals = document.getElementById('goal').value;

    // Meal plan object
    let mealplan = {
        sunday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        },
        monday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        },
        tuesday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        },
        wednesday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        },
        thursday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        },
        friday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        },
        saturday: {
            breakfast: document.getElementById('breakfast').value,
            snack1: document.getElementById('snack1').value,
            lunch: document.getElementById('lunch').value,
            snack2: document.getElementById('snack2').value,
            dinner: document.getElementById('dinner').value
        }
    };

    // Creating a new window to display the meal plan
    let newwindow = window.open("", 'width=800,height=600');
    newwindow.document.write('<html><head><title>Meals</title></head><body>');
    newwindow.document.write('<h1>Meals</h1>');
    newwindow.document.write('<h3>' + name + '\'s Plan</h3>');
    newwindow.document.write('<h4>' + email + '</h4>');
    newwindow.document.write('<p>' + goals + '</p>');

    // Loop through the mealplan object and display the meals
    for (let day in mealplan) {
        newwindow.document.write('<h3>' + day.charAt(0).toUpperCase() + day.slice(1) + '</h3>');
        for (let meal in mealplan[day]) {
            newwindow.document.write('<p><strong>' + meal + ':</strong> ' + mealplan[day][meal] + '</p>');
        }
    }
     // Add Print Button
     newwindow.document.write('<button onclick="window.print()">Print</button>');

     // Add Download Button (uses Blob to create a downloadable text file)
     newwindow.document.write('<button onclick="downloadPlan()">Download</button>');
 
     // Add JavaScript for the download button
     newwindow.document.write(`
         <script>
             function downloadPlan() {
                 let content = document.body.innerText;
                 let blob = new Blob([content], { type: 'text/plain' });
                 let link = document.createElement('a');
                 link.href = window.URL.createObjectURL(blob);
                 link.download = 'meal_plan.txt';
                 link.click();
             }
         </script>
     `);

    newwindow.document.write('</body></html>');
    newwindow.document.close();
}

// //function
// function meal() {
//     // getting the id's for the inputs from the html file yeahhhhh
//     // These comments below are the bane of my existence
//     let name = document.getElementById('name')
//     let email = document.getElementById('email')
//     let goals = document.getElementById('goals')

//     let mealplan = {
//         sunday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         },
//         monday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         },
//         tuesday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         },
//         wednesday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         },
//         thursday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         },
//         friday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         },
//         saturday: {
//             breakfast: document.getElementById('breakfast'),
//             snack1: document.getElementById('snack1'),
//             lunch: document.getElementById('lunch'),
//             snack2: document.getElementById('snack2'),
//             dinner: document.getElementById('dinner')
//         }
//     }

//     let newwindow = window.open(",", 'width=800,height=600')
//     newwindow.document.write('<html><head><h1>Meals</h1> </head>')
//     newwindow.document.write('<h3>' + name + '\'s Plan</h3>');
//     newwindow.document.write('<h4>' + email + '</h4>');
//     newwindow.document.write('<p>' + goals + '</p>');

//     for (let i in mealplan) {
//         newwindow.document.write('<h3>' + i + '</h3>');

//         for (let meal in mealplan[i]) {
//             newwindow.document.write('<p>' + mealplan[i][meal] + '</p>');
  // Add Print Button
  //newwindow.document.write('<button onclick="window.print()">Print</button>');

  // Add Download Button (uses Blob to create a downloadable text file)
  //newwindow.document.write('<button onclick="downloadPlan()">Download</button>');
//         }
//     }
// }
